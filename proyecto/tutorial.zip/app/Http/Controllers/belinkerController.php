<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

class belinkerController extends Controller
{
    
      public function index()
    {



        return view('belinker');
    }

}
