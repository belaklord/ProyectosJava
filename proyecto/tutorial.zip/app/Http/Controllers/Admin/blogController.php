<?php

namespace App\Http\Controllers;

/*para usar las validaciones de forma estática */

use Illuminate\Support\Facades\Validator;

use App\Http\Requests;
/*usamos la clase edicion request para las validaciones de la edicion del usuario*/

use App\Http\Requests\EditUserRequest;


use App\Http\Controllers\Controller;

/*USAMOS FACHADAS */
use Illuminate\Support\Facades\Request;


/*PARA USAR EL ORM ELOQUENT Y HACER LAS CONSULTAS A LA BASE DE DATOS
INTERACTUANDO CON EL MODELO */

use App\Blog;





class blogController extends Controller
{
    
	 public function index()
    {


        return view('admin.adminBlog');
    }


    public function store(Request $request){


			$data = $request::all();


			$rules = [
			'titulo' => 'required',
			'notes' => 'required',
			'foto' => 'required|string:value',
			

			];

			$validator = Validator::make($data, $rules);
			if($validator->fails()){
			return redirect()->back()->withErrors($validator->errors())->withInput($request::except('password'));
			}
			/*inserta los datos en caso correcto, si no muestra el formulario con errores */
			$user = new Blog($data);
			$user->save();
			return view('admin.adminBlog');







}

















}