<?php

namespace App\Http\Controllers;



use App\Http\Requests;

use App\User;

use Illuminate\Support\Facades\Request;
use App\Http\Requests\EditUserRequest;

class usuariosController extends Controller
{
   


public function edit($id){

	$user = User::findOrFail($id);  // findorfail busca el usuario con esa id si no lo encuentra lanza error 404 
	return view('auth.register', compact('user')); // le pasa a la vista de edicion los datos del usuario a editar
}


public function update(Request $request, $id)
{



			$user = User::findOrFail($id);
			$user->fill(Request::all());
			$user->save();
			return redirect()->back();


}


   

}



