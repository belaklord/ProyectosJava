<?php echo $__env->make('cabecera', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<link rel="stylesheet" href="css/adminblog/entradas.css">

<h1>Crear Entrada</h1>

<div class="container">


        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-primary">
                <div class="panel-heading">Entrada de blog</div>
                <div class="panel-body">
                    <?php echo $__env->make('plantillasComunes.errores', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/entradaBlog')); ?>">
                        <?php echo csrf_field(); ?>


                        <div class="form-group<?php echo e($errors->has('titulo') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">Título</label>

                            <div class="col-md-6">
                                <input type="text" class="form-control" name="titulo" value="<?php echo e(old('titulo')); ?>">

                                <?php if($errors->has('titulo')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('titulo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

 							<label class="col-md-4 control-label">Texto</label>

                        <?php echo e(Form::textarea('notes')); ?>


                            <label class="col-md-4 control-label">Imagen</label>

                        <?php echo e(Form::file('foto')); ?>


                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">

                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-btn fa-sign-in"></i>Insertar
                                </button>

                               
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>

</div>

<?php echo $__env->make('pie', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>