<?php echo $__env->make('cabecera', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<link rel="stylesheet" href="css/contrato.css" />


    <?php if(!Auth::user()): ?>

    <p>no estas autenticado</p>

    <!--
    
    CUADRO DE ENVIO DE MENSAJE QUE ENVÍA UN EMAIL A UNA CUENTA DIFERENTE LLAMADA "CONTRATOS"

	-->

    <?php else: ?>

    <p>si estas autenticado</p>

    <?php endif; ?>



</div>
<?php echo $__env->make('pie', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>