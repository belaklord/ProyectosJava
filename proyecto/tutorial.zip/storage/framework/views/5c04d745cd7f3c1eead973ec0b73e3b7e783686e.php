<div class="panel-body">
<div class="container">
   <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-primary">
                <div class="panel-heading">Actualizar Usuario</div>
                 <div class="panel-body">

                        
    <div class="form-group">
                          <?php echo e(Form::label('name', ' Nombre')); ?>

                          <?php echo e(Form::text('name', null, ['class' => 'form-control',
                          'placeholder' => 'Nombre'])); ?>

                          </div>

                          <div class="form-group">
                          <?php echo e(Form::label('apellidos', 'Apellidos')); ?>

                          <?php echo e(Form::text('apellidos', null, ['class' => 'form-control',
                          'placeholder' => ' Apellidos'])); ?>

                          </div>

                          <div class="form-group">
                          <?php echo e(Form::label('email', 'Correo electrónico')); ?>

                          <?php echo e(Form::text('email', null, ['class' => 'form-control',
                          'placeholder' => ' e-mail'])); ?>

                          </div>

                          <div class="form-group">
                          <?php echo e(Form::label('direccion', 'Direccion')); ?>

                          <?php echo e(Form::text('direccion', null, ['class' => 'form-control',
                          'placeholder' => 'Direccion'])); ?>

                          </div>

                           <div class="form-group">
                         
                          <?php echo e(Form::hidden('user_id', Auth::user()->id, ['class' => 'form-control'])); ?>

                          </div>

                          
                    <button type="submit" class="btn btn-info">Actualiza</button>

                        </div>
                    