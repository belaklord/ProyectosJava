
<?php echo $__env->make('cabecera', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<link rel="stylesheet" href="css/blog.css">

<?php 

$page = 1;
 ?>
<?php foreach($result as $contacto): ?> <!-- BUCLE QUE RECORRE LA TABLA PARA MOSTARAR LOS USUARIOS -->


<div class="articulo">

	<article>
	
<div class="contenido">

	<?php 

	echo "<a href= 'http://localhost/proyecto/public/blog/create?page= $page' > ";
	$page ++;
	
 	
	 ?>
	<!-- añadir referencia para que se muestre la imagen en grande -->

<img class="imagen-blog" src="<?php echo e('imagenes/blog/' .$contacto->foto); ?>" alt=""></a>

<div class="texto">

	<?php echo e($contacto->titulo); ?>

	

</div>

</div>


</div>


<?php endforeach; ?>


</div>

<?php echo $__env->make('pie', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>