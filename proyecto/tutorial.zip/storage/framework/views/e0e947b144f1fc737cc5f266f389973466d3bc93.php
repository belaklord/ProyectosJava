
<?php echo $__env->make('cabecera', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<link rel="stylesheet" href="css/blog.css">


    <div class="titulo">
        
<h3>BELINKER</h3>

    </div>


</div>
<!-- en cada include del pie añadir una etiqueta de cierre de div -->

<?php echo $__env->make('pie', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
