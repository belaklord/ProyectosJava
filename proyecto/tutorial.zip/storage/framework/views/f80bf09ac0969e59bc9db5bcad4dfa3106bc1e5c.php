

<?php echo $__env->make('cabecera', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



<?php if(Auth::user()): ?>


<link rel="stylesheet" href="../../css/cabecera.css" />
<link rel="stylesheet" href="../../css/pie.css" />
<link rel="stylesheet" href="../../css/registro.css">

<div class="col-md-10 col-md-offset-1">

<?php echo e(Form::model($user, ['route' => ['usuarios.update',$user->id], 'method' => 'PUT'])); ?>


 
        

                <?php echo $__env->make('plantillasComunes.actualiza', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <?php echo e(Form::close()); ?>


</div>
<?php else: ?>


 
<link rel="stylesheet" href="css/cabecera.css" />
<link rel="stylesheet" href="css/pie.css" />
<link rel="stylesheet" href="css/registro.css">

<script src='https://www.google.com/recaptcha/api.js'></script> <!-- script del captcha -->

<div class="col-md-10 col-md-offset-1">

<?php echo e(Form::open(array('url' => 'User/insertar'))); ?>



                <?php echo $__env->make('plantillasComunes.registro', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>




<?php echo e(Form::close()); ?>


</div>
<?php endif; ?>


    				</div>
                </div>
            </div>
        </div>
    </div>

</div>

<!-- en cada include del pie añadir una etiqueta de cierre de div -->
</div>


    
</html>
<?php echo $__env->make('pie', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>