<?php echo $__env->make('cabecera', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<link rel="stylesheet" href="css/adminUsers/usuarios.css">


   
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Usuarios</div>
                    <div class="panel-body">
                        <?php if(Session::has('message')): ?>
                        
                        <p class="alert alert-success">
                        <?php echo e(Session::get('message')); ?>

                        </p>
                        <?php endif; ?>
                        <!--boton para crear nuevos usuarios -->
   
                   
  			 <!--tabla sacada de la web bootstrap/css-->
                <table class="table table-condensed">
                    <th class="success">ID contacto</th>
                    <th class="success">NOMBRE</th>
                    <th class="success">EMAIL</th>
                    <th class="success">Telefono</th>
                    <th class="success">Dirección</th>
                   

                      <?php foreach($result as $usuario): ?> <!-- BUCLE QUE RECORRE LA TABLA PARA MOSTARAR LOS USUARIOS -->
                    <tr>
                        
                       <td class="success"><?php echo e($usuario->id); ?></td>
                        <td class="warning"><?php echo e($usuario->name); ?></td>
                        <td class="warning"><?php echo e($usuario->apellidos); ?></td>
                        <td class="warning"><?php echo e($usuario->email); ?></td>
                        <td class="warning"><?php echo e($usuario->direccion); ?></td>
                        <td>
                         
                         <a class="btn btn-info" href="<?php echo e(route('usuarios.edit', $usuario->id)); ?>">Editar</a>
 
                        <a class="btn btn-danger" href=" ">Borrar</a>
 
                          
                       
                        </td>
                    </tr>
                    <?php endforeach; ?>
                   
                </table>

                    <?php echo $result->render(); ?>




                    </div>
            </div>
        </div>
    
</div>



<?php echo $__env->make('pie', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

