



 <div class="panel-body">
<div class="container">
   <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-primary">
                <div class="panel-heading">Nuevo Usuario</div>
                 <div class="panel-body">

    
                        <div class="form-group">
                          <?php echo e(Form::label('name', ' Nombre')); ?>

                          <?php echo e(Form::text('name', null, ['class' => 'form-control',
                          'placeholder' => 'Nombre'])); ?>

                          </div>

                          <div class="form-group">
                          <?php echo e(Form::label('apellidos', 'Apellidos')); ?>

                          <?php echo e(Form::text('apellidos', null, ['class' => 'form-control',
                          'placeholder' => ' Apellidos'])); ?>

                          </div>

                          <div class="form-group">
                          <?php echo e(Form::label('email', 'Correo electrónico')); ?>

                          <?php echo e(Form::text('email', null, ['class' => 'form-control',
                          'placeholder' => ' e-mail'])); ?>

                          </div>

                          <div class="form-group">
                          <?php echo e(Form::label('direccion', 'Direccion')); ?>

                          <?php echo e(Form::text('direccion', null, ['class' => 'form-control',
                          'placeholder' => 'Direccion'])); ?>

                          </div>


                          <div class="form-group">
                          <?php echo e(Form::label('password', 'Contraseña')); ?>

                          <?php echo e(Form::password('password', ['class' => 'form-control',
                          'placeholder' => ' password'])); ?>

                          </div>

                          <div class="form-group">
                          <?php echo e(Form::label('password', 'Repite Contraseña')); ?>

                          <?php echo e(Form::password('password_confirmation', ['class' => 'form-control',
                          'placeholder' => ' password'])); ?>

                          </div>
                            <!-- muestra el  captcha en el formulario -->
                         <div class="g-recaptcha" data-sitekey="6Lf16B8TAAAAAF54Imzsln1fkFZxb76ebFPAfHUZ"></div>


                 <button type="submit" class="btn btn-info">Registrar</button>

                        

                        </div>
                    