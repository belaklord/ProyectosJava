
<?php echo $__env->make('cabecera', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<link rel="stylesheet" href="css/belinker.css">


	<div class="titulo">
		
<h3>BELINKER</h3>

	</div>

	<div class="migaspan">

<ol class="breadcrumb">
  <li><a href="<?php echo e(url('/home')); ?>">HOME</a></li>
  <li class="active">BELINKER</li>
</ol>

</div>
 
	

<div class="contenido" >

<p>
	Belinker es un grupo de estudiantes de Ingeniería informática residentes en Murcia,
	nacida desde la ilusión y motivación de sus componentes por este sector hace 1 año, dedicada a la reparación de todo tipo de ordenadores y 
	sistemas informáticos a particulares y empresas.
	Comenzamos este nuevo proyecto de promocionarnos e involucrarnos más a fondo en este sector debido al éxito de estos últimos meses.

</p>
	

	</div>



	<div class="belinker">
		

	<img  src="http://belinker.es/wp-content/uploads/2015/07/belinker2.png" alt="belinker">

<div class="contacto">

		<p>
			Contacto:


	
	info@belinker.es

	
	680 70 12 11 / 635 44 61 12



	Murcia, 3000

</p>



	</div>
	</div>


	




</div>



<?php echo $__env->make('pie', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>