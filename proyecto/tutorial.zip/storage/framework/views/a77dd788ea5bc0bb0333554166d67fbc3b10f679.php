<?php echo $__env->make('cabecera', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--rutas relativas para acceder al css en esta vista no se ha encontrado 
otra forma ya que no está en el archivo de rutas , se accede desde la otroa vista blog -->
<link rel="stylesheet" href="../css/vistaBlog.css" />
<link rel="stylesheet" href="../css/cabecera.css">
<link rel="stylesheet" href="../css/pie.css">




                <?php foreach($result as $contacto): ?> <!-- BUCLE QUE RECORRE LA TABLA PARA MOSTARAR LOS USUARIOS -->
              
<div class="contenido" >

    <h3> <?php echo e($contacto->titulo); ?></h3>


    <p>
    
 <?php echo e($contacto->notes); ?>

    </p>

    <div>
          <img class="imagen-blog" src="<?php echo e('../imagenes/blog/'.$contacto->foto); ?>" alt="">
    </div>


    

    </div>


       
                    <?php endforeach; ?>
                        
            
               <?php echo $result->render(); ?>

    </div>

<?php echo $__env->make('pie', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
                    
                   
