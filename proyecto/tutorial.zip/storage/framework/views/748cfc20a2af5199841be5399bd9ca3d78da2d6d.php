
<p>
	Comentario de <?php echo e(Auth::user()->name); ?>

	<br>
	Con Email <?php echo e(Auth::user()->email); ?>

	<br>
	Contenido del email:
	<br>
	<?php echo e($contenido); ?>



</p>





