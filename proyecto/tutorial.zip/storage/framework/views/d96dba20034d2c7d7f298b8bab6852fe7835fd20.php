
<link rel="stylesheet" href="css/pie.css" />

     <nav  class="navbar navbar-inverse navbar-static-top">

     	<img class="icono2" srcset="http://belinker.es/wp-content/uploads/2015/07/belinker2.png 1x,
     								 http://belinker.es/wp-content/uploads/2015/07/belinker2.png 2x" 
     	alt="Belinker" 
     	src="http://belinker.es/wp-content/uploads/2015/07/belinker2.png">

     </nav>


    <!-- JavaScripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <?php /* <script src="<?php echo e(elixir('js/app.js')); ?>"></script> */ ?>