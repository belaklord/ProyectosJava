<?php 

use Illuminate\Support\Facades\Hash;




 echo( "<p> Tu nueva contraseña es :". " " . $password . "</p>"); //muestra la nueva contraseña en tu correo //


 ?>
