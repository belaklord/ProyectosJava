
@include('cabecera')

<link rel="stylesheet" href="../css/vistaemail.css" />
<link rel="stylesheet" href="../css/cabecera.css">
<link rel="stylesheet" href="../css/pie.css">



<div class="panel panel-success">

 <div class="panel-heading">Email Enviado</div>
 

<h3>Se ha enviado un email a su correo</h3>
<br>
<h4>
	Gracias por registrarse
</h4>


</div>
</div>

@include('pie')