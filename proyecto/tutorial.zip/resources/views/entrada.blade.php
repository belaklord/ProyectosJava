
@include('cabecera')

<link rel="stylesheet" href="css/adminBlog/entradas.css">


    <div class="titulo">
        
<h3>BELINKER</h3>

    </div>


</div>
<!-- en cada include del pie añadir una etiqueta de cierre de div -->

@include('pie')
    
