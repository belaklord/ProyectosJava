
		<a href="home" ><img class="icono" srcset="http://belinker.es/wp-content/uploads/2015/07/belinker2.png 1x, http://belinker.es/wp-content/uploads/2015/07/belinker2.png 2x" 
        alt="Belinker"  src="http://belinker.es/wp-content/uploads/2015/07/belinker2.png"></a>

<p>
	bienvenido a belinker 
</p>