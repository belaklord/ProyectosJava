
<p>
	Comentario de {{Auth::user()->name}}
	<br>
	Con Email {{Auth::user()->email}}
	<br>
	Contenido del email:
	<br>
	{{$contenido}}


</p>





